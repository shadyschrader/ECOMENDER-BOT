
/*
* EcoMender Bot (EB): Task 2B Path Planner
*
* This program computes the valid path from the start point to the end point.
* Make sure you don't change anything outside the "Add your code here" section.
*/

#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <limits.h>
#define V 32

#ifdef __linux__ // for host pc

    #include <stdio.h>

    void _put_byte(char c) { putchar(c); }

    void _put_str(char *str) {
        while (*str) {
            _put_byte(*str++);
        }
    }

    void print_output(uint8_t num) {
        if (num == 0) {
            putchar('0'); // if the number is 0, directly print '0'
            _put_byte('\n');
            return;
        }

        if (num < 0) {
            putchar('-'); // print the negative sign for negative numbers
            num = -num;   // make the number positive for easier processing
        }

        // convert the integer to a string
        char buffer[20]; // assuming a 32-bit integer, the maximum number of digits is 10 (plus sign and null terminator)
        uint8_t index = 0;

        while (num > 0) {
            buffer[index++] = '0' + num % 10; // convert the last digit to its character representation
            num /= 10;                        // move to the next digit
        }
        // print the characters in reverse order (from right to left)
        while (index > 0) { putchar(buffer[--index]); }
        _put_byte('\n');
    }

    void _put_value(uint8_t val) { print_output(val); }

#else  // for the test device

    void _put_value(uint8_t val) { }
    void _put_str(char *str) { }

#endif

// main function
int main(int argc, char const *argv[]) {

    #ifdef __linux__

        const uint8_t START_POINT   = atoi(argv[1]);
        const uint8_t END_POINT     = atoi(argv[2]);
        uint8_t NODE_POINT          = 0;
        uint8_t CPU_DONE            = 0;

    #else
        // Address value of variables for RISC-V Implementation
        #define START_POINT         (* (volatile uint8_t * ) 0x02000000)
        #define END_POINT           (* (volatile uint8_t * ) 0x02000004)
        #define NODE_POINT          (* (volatile uint8_t * ) 0x02000008)
        #define CPU_DONE            (* (volatile uint8_t * ) 0x0200000c)

    #endif

    // array to store the planned path
    uint8_t path_planned[32];
    // index to keep track of the path_planned array
    uint8_t idx = 0;

    /* Functions Usage

    instead of using printf() function for debugging,
    use the below function calls to print a number, string or a newline

    for newline: _put_byte('\n');
    for string:  _put_str("your string here");
    for number:  _put_value(your_number_here);

    Examples:
            _put_value(START_POINT);
            _put_value(END_POINT);
            _put_str("Hello World!");
            _put_byte('\n');
    */

    // ############# Add your code here #############
    // prefer declaring variable like this
struct Vertex {
    uint8_t status;      // TEMPORARY or PERMANENT
    uint8_t predecessor; // Predecessor node
    uint8_t pathLength;  // Path length from start node
    char name[3];        // Node name (max of 2 digits + null terminator)
};

struct Vertex vertexList[V];
uint8_t n = 0; // Number of vertices
uint8_t adj[V * V] = {0}; // Initialize adjacency matrix to zero

// Initialize vertex names and the adjacency matrix
void initialize_graph() {
    for (uint8_t i = 0; i < V; i++) {
        vertexList[i].status = 1; // Set all vertices as temporary
        vertexList[i].pathLength = 245; // Set initial path lengths to infinity
        vertexList[i].predecessor = UINT8_MAX; // No predecessor
        vertexList[i].name[0] = '0' + (i / 10); // Tens place
        vertexList[i].name[1] = '0' + (i % 10); // Units place
        vertexList[i].name[2] = '\0'; // Null-terminate
    }
}

// Function to add edges in both directions
void add_edge(uint8_t u, uint8_t v, uint8_t w) {
    adj[u * V + v] = w;
    adj[v * V + u] = w;
}

// Define edges using the function
void define_edges() {
    uint8_t edges[][3] = {
        {0, 1, 2}, {0, 10, 5}, {0, 6, 8}, {1, 11, 2}, {1, 2, 3}, 
        {2, 5, 4}, {2, 3, 7}, {2, 4, 8}, {6, 7, 9}, {6, 8, 4}, 
        {6, 9, 6}, {7, 3, 5}, {7, 5, 3}, {7, 8, 5}, {10, 26, 3}, 
        {10, 24, 3}, {10, 11, 3}, {11, 19, 3}, {11, 12, 3}, 
        {12, 13, 3}, {12, 14, 3}, {14, 15, 3}, {14, 16, 3}, 
        {16, 17, 3}, {16, 18, 3}, {18, 21, 3}, {18, 19, 3}, 
        {19, 20, 3}, {21, 23, 3}, {21, 22, 3}, {23, 24, 3}, 
        {23, 30, 3}, {24, 25, 3}, {26, 28, 3}, {26, 27, 3}, 
        {28, 29, 3}, {28, 30, 3}, {30, 31, 3}
    };
    
    for (size_t i = 0; i < sizeof(edges) / sizeof(edges[0]); i++) {
        add_edge(edges[i][0], edges[i][1], edges[i][2]);
    }
}

// Find the vertex with the minimum path length
uint8_t tempVertexMinPL() {
    uint8_t min = UINT8_MAX, x = UINT8_MAX;

    for (uint8_t v = 0; v < n; v++) {
        if (vertexList[v].status == 1 && vertexList[v].pathLength < min) {
            min = vertexList[v].pathLength;
            x = v;
        }
    }
    return x;
}

// Dijkstra's algorithm implementation
void dijkstra(uint8_t start) {
    vertexList[start].pathLength = 0; // Starting vertex has a path length of 0

    while (true) {
        uint8_t c = tempVertexMinPL();
        if (c == UINT8_MAX) return; // No more temporary vertices

        vertexList[c].status = 2; // Mark the vertex as permanent

        for (uint8_t v = 0; v < n; v++) {
            uint8_t weight = adj[c * V + v]; // Get the edge weight
            if (weight != 0 && vertexList[v].status == 1) {
                // Relaxation step
                if (vertexList[c].pathLength + weight < vertexList[v].pathLength) {
                    vertexList[v].predecessor = c;
                    vertexList[v].pathLength = vertexList[c].pathLength + weight;
                }
            }
        }
    }
}

// Function to find and store the path from start to end
void findPath(uint8_t start, uint8_t end) {
    uint8_t path[V], count = 0, sd = 0; // Shortest distance

    // Traverse from end to start
    for (uint8_t v = end; v != start; v = vertexList[v].predecessor) {
        path[count++] = v;
        sd += adj[vertexList[v].predecessor * V + v];
    }
    path[count++] = start; // Include the start node

    // Store the path in the path_planned array in the correct order
    for (int i = count - 1; i >= 0; i--) {
        path_planned[idx++] = path[i]; // Add node to path_planned
    }
}

// Main logic
initialize_graph(); // Initialize vertex names and adjacency matrix
n = V; // Set number of vertices
define_edges(); // Define edges before running Dijkstra's algorithm
uint8_t start = START_POINT; 
dijkstra(start);

uint8_t end = END_POINT; // Target end point
if (vertexList[end].pathLength == UINT8_MAX) {
    _put_str("There is no path from ");
    _put_str(vertexList[start].name);
    _put_str(" to ");
    _put_str(vertexList[end].name);
} else {    
    findPath(start, end); // Find and display the path from start to end
}

    // ##############################################

    // the node values are written into data memory sequentially.
    for (int i = 0; i < idx; ++i) {
        NODE_POINT = path_planned[i];
    }
    // Path Planning Computation Done Flag
    CPU_DONE = 1;

    #ifdef __linux__    // for host pc

        _put_str("######### Planned Path #########\n");
        for (int i = 0; i < idx; ++i) {
            _put_value(path_planned[i]);
        }
        _put_str("################################\n");

    #endif

    return 0;
}

